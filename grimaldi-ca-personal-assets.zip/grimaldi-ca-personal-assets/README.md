# grimaldi.ca — Personal Visual Assets

These 10 professional images support the personal site focused on **bio and story, broader engineering ambitions and aspirations, podcast, writing/explainers, selected projects, and contact**.

They explicitly include current practical help to **EcoWoods** (Toronto hardwood contractor + job-management app) and **Plastilonas** as side engineering work — not as proving grounds.

**Upload location recommendation:**  
`/public/images/personal/` in the grimaldi.ca repo.

All images are landscape (approx. 1176×784), dark elegant professional aesthetic, suitable for a lighter, human-facing surface.

---

### Context from public profile (iceccarelli)

- Electrical Engineering · Cyber-Physical Systems · Critical Infrastructure · Digital Twins · Physics-Informed AI
- Frankfurt / Toronto
- Languages: English · German · Spanish · Mandarin
- Broader integration: Physics + Electrical Engineering + Software + Data + AI + Cybersecurity + Automation + Human Engineering
- Active TikTok presence (@vincenzo.ceccarel4)
- Helps EcoWoods (Toronto hardwood flooring) and Plastilonas as practical side work

---

### Image Inventory + Placement + SEO/AEO

| # | Filename | Primary Use | Alt Text (SEO) | Recommended Placement | AEO / Content Notes |
|---|----------|-------------|----------------|-----------------------|---------------------|
| 01 | `01-personal-engineering-workspace.jpg` | Hero / bio | Personal engineering workspace overlooking the city at dusk | Homepage hero or About section | Sets the human, reflective tone. |
| 02 | `02-podcast-recording-setup.jpg` | Podcast | Professional podcast recording setup with microphone and notebook | Podcast section | Direct support for podcast ambition (YouTube or new show). |
| 03 | `03-ecowoods-hardwood-craftsmanship.jpg` | Side work | Hardwood flooring craftsmanship detail in Toronto | EcoWoods mention / selected projects | Shows practical help without framing as a “proving ground.” |
| 04 | `04-broader-engineering-ambitions.jpg` | Ambitions | Broader engineering ambitions merging grids, machines, and digital systems | Ambitions / aspirations section | Reflects the “bigger picture” from the GitHub profile. |
| 05 | `05-writing-explainers.jpg` | Writing | Writing and technical explainers with notebooks and engineering diagrams | Writing / explainers section | For general articles that do not fit the pure electrical site. |
| 06 | `06-plastilonas-side-engineering.jpg` | Side work | Precision engineering workshop and materials for side projects | Plastilonas / selected projects | Honest side engineering work visual. |
| 07 | `07-toronto-frankfurt-dual-life.jpg` | Personal story | Toronto and Frankfurt dual life connected through engineering | Bio / personal story | Reflects the two bases. |
| 08 | `08-selected-projects.jpg` | Projects | Selected engineering projects, sketches, and models | Selected projects section | Clean portfolio-style overview. |
| 09 | `09-human-aspirations-engineer.jpg` | Aspirations | Engineer contemplating infrastructure and the horizon at dusk | Human aspirations section | Contemplative, personal tone. |
| 10 | `10-contact-connection.jpg` | Contact | Minimal professional desk for contact and connection | Contact section | Inviting, low-friction close. |

---

### Suggested Page Structure

1. **Hero**  
   Image: `01-personal-engineering-workspace.jpg` or `09-...`  
   Headline: Vincenzo Ceccarelli Grimaldi  
   Sub: Electrical engineer. Broader ambitions in engineering, writing, and conversation.

2. **Bio & Story**  
   Image: `07-toronto-frankfurt-dual-life.jpg`  
   Frankfurt / Toronto. Day job at DB InfraGO AG. Founder of Time to Power and NeuralBridge. Languages: EN · DE · ES · ZH.

3. **Broader Ambitions**  
   Image: `04-broader-engineering-ambitions.jpg`  
   Physics + Electrical Engineering + Software + Data + AI + Human Engineering.

4. **Podcast**  
   Image: `02-podcast-recording-setup.jpg`  
   Link existing YouTube channel or new show.

5. **Writing / Explainers**  
   Image: `05-writing-explainers.jpg`  
   General pieces that do not belong on the pure electrical site.

6. **Selected Projects & Side Work**  
   - EcoWoods: `03-ecowoods-hardwood-craftsmanship.jpg` + link to the app / ecowoods.ca  
   - Plastilonas: `06-plastilonas-side-engineering.jpg`  
   - Other: `08-selected-projects.jpg`

7. **Contact**  
   Image: `10-contact-connection.jpg`

---

### SEO / AEO Recommendations

- File names are descriptive and human-facing.  
- Use the provided alt texts.  
- Keep language personal and honest — no cluster, operations, or control-surface terminology.  
- Explicitly name EcoWoods and Plastilonas as current practical help.  
- Link to the companies hub (engineeringgrimaldi.com) and electrical site (igrimaldi.engineering) where relevant.  
- Open Graph: use 01 or 07 as primary social image.

---

### Kill List (do not reintroduce)

- Cluster / operations control surface language  
- KPI boards, weekly CEO reports, kill lists  
- EcoWoods or any side work framed as a “proving ground” for a larger system  
- Any implication of a group operating system

This surface can stay lighter and grow gradually with podcast episodes, writing, and selected work.  
Upload into the public directory of the grimaldi.ca repository.
